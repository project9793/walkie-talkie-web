'use strict';

/**
 * Walkie-Talkie relay server.
 *
 * - Serves the static client from ./public
 * - Accepts WebSocket connections on /ws
 * - Puts clients into "rooms" (one public channel, or one private key)
 * - Relays small binary PCM frames + text messages inside a room
 *
 * Nothing is stored: no accounts, no database, no recordings.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer, WebSocket } = require('ws');

// Static files live in ./public when the folder structure is intact, but the
// server also accepts them flat next to server.js (useful when files were
// uploaded one by one through the GitHub web UI).
const STATIC_DIRS = [path.join(__dirname, 'public'), __dirname];

// In flat mode (files sitting next to server.js) only these client assets may
// be served — never server.js, package.json or anything else from the repo.
const FLAT_ALLOWED = new Set([
  'index.html', 'style.css', 'app.js', 'capture-worklet.js',
  'favicon.ico', 'favicon.png', 'manifest.webmanifest',
]);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json',
};

// ---- limits (keep a noisy or malicious client from flooding a room) ----
const MAX_FRAME_BYTES = 8192;        // one audio frame, ~250 ms at 16 kHz mono
const MAX_BYTES_PER_SEC = 120000;    // a talker at 16 kHz mono needs ~32 KB/s
const MAX_FRAMES_PER_SEC = 400;
const MAX_TEXT_LEN = 300;
const MAX_ROOM_SIZE = 50;

function serveStatic(req, res) {
  const url = new URL(req.url, 'http://localhost');
  let pathname;
  try {
    pathname = decodeURIComponent(url.pathname);
  } catch {
    res.writeHead(400).end('Bad request');
    return;
  }
  if (pathname === '/') pathname = '/index.html';

  const safe = path.normalize(pathname).replace(/^([.][.][/\\])+/, '');

  let filePath = null;
  for (const dir of STATIC_DIRS) {
    const candidate = path.join(dir, safe);
    if (!candidate.startsWith(dir + path.sep)) continue;
    if (dir === __dirname && !FLAT_ALLOWED.has(path.basename(candidate))) continue;
    try {
      if (fs.statSync(candidate).isFile()) { filePath = candidate; break; }
    } catch { /* not here, try the next dir */ }
  }

  if (!filePath) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Not found');
    return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Not found');
      return;
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(data);
  });
}

function roomLabel(state) {
  return state.private ? 'प्राइवेट' : 'पब्लिक #' + state.channel;
}

function start(port = process.env.PORT || 3000) {
  const httpServer = http.createServer(serveStatic);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws', maxPayload: 64 * 1024 });

  /** @type {Map<string, Set<WebSocket>>} room id -> sockets */
  const rooms = new Map();
  /** @type {WeakMap<WebSocket, object>} socket -> state */
  const states = new WeakMap();

  function peersOf(roomId) {
    const set = rooms.get(roomId);
    if (!set) return [];
    return [...set].filter((s) => s.readyState === WebSocket.OPEN);
  }

  function send(socket, obj) {
    if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(obj));
  }

  function broadcastPeers(roomId) {
    const peers = peersOf(roomId);
    const ids = peers.map((s) => states.get(s)?.id).filter(Boolean);
    for (const p of peers) send(p, { t: 'peers', count: peers.length, ids });
  }

  function leaveRoom(state) {
    const set = rooms.get(state.room);
    if (!set) return;
    set.delete(state.ws);
    if (set.size === 0) rooms.delete(state.room);
    else {
      for (const p of peersOf(state.room)) send(p, { t: 'talk', id: state.id, on: false });
      broadcastPeers(state.room);
    }
  }

  wss.on('connection', (ws) => {
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });

    const state = {
      id: crypto.randomBytes(3).toString('hex'),
      room: null,
      channel: null,
      private: false,
      talking: false,
      bytesWindowStart: 0,
      bytesInWindow: 0,
      framesInWindow: 0,
      ws,
    };
    states.set(ws, state);

    send(ws, { t: 'hello', id: state.id });

    ws.on('message', (data, isBinary) => {
      // ---- audio frames ----
      if (isBinary) {
        if (!state.room) return;
        const now = Date.now();
        if (now - state.bytesWindowStart > 1000) {
          state.bytesWindowStart = now;
          state.bytesInWindow = 0;
          state.framesInWindow = 0;
        }
        state.bytesInWindow += data.length;
        state.framesInWindow += 1;
        if (data.length > MAX_FRAME_BYTES) return;
        if (state.bytesInWindow > MAX_BYTES_PER_SEC) return;
        if (state.framesInWindow > MAX_FRAMES_PER_SEC) return;

        for (const peer of peersOf(state.room)) {
          if (peer !== ws && peer.readyState === WebSocket.OPEN) {
            peer.send(data, { binary: true });
          }
        }
        return;
      }

      // ---- control messages ----
      let msg;
      try {
        msg = JSON.parse(data.toString());
      } catch {
        return;
      }
      if (!msg || typeof msg.t !== 'string') return;

      if (msg.t === 'join') {
        if (state.room) leaveRoom(state);

        const key = typeof msg.key === 'string' ? msg.key.trim() : '';
        let roomId;
        if (key) {
          if (key.length < 4) {
            send(ws, { t: 'error', msg: 'की-कोड कम से कम 4 अक्षर का होना चाहिए।' });
            return;
          }
          state.private = true;
          state.channel = null;
          roomId = 'p:' + crypto.createHash('sha256').update(key).digest('hex').slice(0, 24);
        } else {
          const channel = Number(msg.channel);
          if (!Number.isInteger(channel) || channel < 1 || channel > 50) {
            send(ws, { t: 'error', msg: 'चैनल 1 से 50 के बीच चुनें।' });
            return;
          }
          state.private = false;
          state.channel = channel;
          roomId = 'c:' + channel;
        }

        state.room = roomId;
        if (!rooms.has(roomId)) rooms.set(roomId, new Set());
        if (rooms.get(roomId).size >= MAX_ROOM_SIZE) {
          state.room = null;
          send(ws, { t: 'error', msg: 'यह चैनल भरा हुआ है। दूसरा चैनल चुनें।' });
          return;
        }
        rooms.get(roomId).add(ws);

        send(ws, { t: 'joined', id: state.id, room: roomLabel(state) });
        broadcastPeers(roomId);
        return;
      }

      if (!state.room) return;

      if (msg.t === 'talk') {
        state.talking = !!msg.on;
        for (const peer of peersOf(state.room)) {
          if (peer !== ws) send(peer, { t: 'talk', id: state.id, on: state.talking });
        }
        return;
      }

      if (msg.t === 'msg') {
        const body = typeof msg.body === 'string' ? msg.body.slice(0, MAX_TEXT_LEN).trim() : '';
        if (!body) return;
        for (const peer of peersOf(state.room)) {
          send(peer, { t: 'msg', id: state.id, body });
        }
        return;
      }

      if (msg.t === 'ping') send(ws, { t: 'pong' });
    });

    ws.on('close', () => {
      leaveRoom(state);
      state.room = null;
    });

    ws.on('error', () => {
      try { ws.terminate(); } catch { /* ignore */ }
    });
  });

  // drop dead connections
  const heartbeat = setInterval(() => {
    for (const ws of wss.clients) {
      if (ws.isAlive === false) { ws.terminate(); continue; }
      ws.isAlive = false;
      try { ws.ping(); } catch { /* ignore */ }
    }
  }, 30000);
  wss.on('close', () => clearInterval(heartbeat));

  httpServer.listen(port, () => {
    const addr = httpServer.address();
    const p = typeof addr === 'object' && addr ? addr.port : port;
    console.log('वॉकी-टॉकी सर्वर चल रहा है: http://localhost:' + p);
  });

  return { httpServer, wss };
}

if (require.main === module) {
  start(process.env.PORT || 3000);
}

module.exports = { start };
